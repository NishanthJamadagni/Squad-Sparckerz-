# SignConnect AI — Frontend

A responsive HTML, CSS and JavaScript frontend inspired by the supplied Indian Sign Language Recognition dashboard.

## Files
- `index.html` — page structure
- `style.css` — layout, colors, responsive design
- `script.js` — camera preview, chat demo, language selection and speech playback

## Run in VS Code
1. Extract the ZIP file.
2. Open the extracted `signconnect_frontend` folder in VS Code.
3. Make sure all three files (`index.html`, `style.css`, `script.js`) are in the same folder.
4. Install the **Live Server** extension if you have not already.
5. Right-click `index.html` and choose **Open with Live Server**.

The browser should open the dashboard. Click **Start Recognition** and allow camera permission to see your live camera preview.

## Important: what is and isn't connected
This is the frontend only. The camera preview works, and the chat, language dropdown, and browser text-to-speech are demo interactions. Actual Indian Sign Language detection requires a trained recognition model (for example, a Python backend using MediaPipe/OpenCV and a classification model). Real multilingual AI replies and secure login also require backend/API and authentication integration.
